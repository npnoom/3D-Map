const V='v1',SHELL=['./','index.html','app.js','manifest.webmanifest','icon-192.png','icon-512.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open('shell-'+V).then(c=>c.addAll(SHELL)));self.skipWaiting()});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!=='shell-'+V&&k!=='tiles').map(k=>caches.delete(k)))));self.clients.claim()});
async function trim(c){const k=await c.keys();if(k.length>800)for(const x of k.slice(0,k.length-800))c.delete(x)}
self.addEventListener('fetch',e=>{
  const r=e.request;if(r.method!=='GET')return;
  const u=new URL(r.url),tile=/openstreetmap|arcgisonline|amazonaws/.test(u.host);
  if(tile||u.host==='cdn.jsdelivr.net'){
    e.respondWith(caches.open(tile?'tiles':'shell-'+V).then(async c=>{
      const hit=await c.match(r);
      const net=fetch(r).then(res=>{if(res.ok){c.put(r,res.clone());if(tile)trim(c)}return res}).catch(()=>hit);
      return hit||net;
    }));
  }else if(u.origin===location.origin){
    e.respondWith(fetch(r).then(res=>{const cp=res.clone();caches.open('shell-'+V).then(c=>c.put(r,cp));return res}).catch(()=>caches.match(r,{ignoreSearch:true})));
  }
});
